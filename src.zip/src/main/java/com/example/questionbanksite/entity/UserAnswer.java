/*
package com.example.questionbanksite.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "user_answer")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserAnswer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String answer;

    private int score;

    private int correct;

    private double percentage;

    @ManyToOne
    @JoinColumn(name = "result_id")
    private UserResult result;

    @OneToOne
    private Question question;

}
*/
