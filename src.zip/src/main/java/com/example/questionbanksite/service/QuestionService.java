package com.example.questionbanksite.service;



import com.example.questionbanksite.entity.Question;

import java.util.List;

public interface QuestionService {

    Question saveQuestion(Question question);

    List<Question> getAllQuestion();



}
